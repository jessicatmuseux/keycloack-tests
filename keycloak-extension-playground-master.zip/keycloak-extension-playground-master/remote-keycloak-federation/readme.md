Keycloak User Federation
---

PoC for a Keycloak to Keycloak User-Federation.