Provisioning Event Listener example
---

Simple example for reacting to user provisioning events.