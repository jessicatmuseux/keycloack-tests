package keycloak.auth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
class MfaResponse {

    private String errorCode;
}
