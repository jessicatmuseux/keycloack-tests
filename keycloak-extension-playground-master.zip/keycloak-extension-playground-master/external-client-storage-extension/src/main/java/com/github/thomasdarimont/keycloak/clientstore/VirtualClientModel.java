package com.github.thomasdarimont.keycloak.clientstore;

import org.keycloak.models.ClientModel;

public interface VirtualClientModel extends ClientModel {
}