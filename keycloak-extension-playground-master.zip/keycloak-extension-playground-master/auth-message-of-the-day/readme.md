Example for a Message of the Day Authenticator
---

Simple Authenticator implementation that shows a message of the Day.