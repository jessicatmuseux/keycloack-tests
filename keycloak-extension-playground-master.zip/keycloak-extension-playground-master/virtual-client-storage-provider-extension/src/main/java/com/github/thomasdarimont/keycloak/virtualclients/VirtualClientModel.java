package com.github.thomasdarimont.keycloak.virtualclients;

import org.keycloak.models.ClientModel;

public interface VirtualClientModel extends ClientModel {
}
