package de.denniskniep.keycloak.hsm.crypki.service;

public class BlobKeyResponse {

    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
