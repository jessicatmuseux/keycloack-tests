package de.denniskniep.keycloak.hsm.crypki.service;

public class BlobKeySigningResponse {

    private String signature;

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
}
